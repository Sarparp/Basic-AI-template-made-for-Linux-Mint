import tkinter as tk
from tkinter import scrolledtext
import random
import re
import json
import os
from playsound import playsound
import threading

# --------------------
# Memory / Brain
# --------------------
MEMORY_FILE = "ai_memory.json"

# Load memory
if os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "r") as f:
        memory = json.load(f)
else:
    memory = {}

# Ensure required keys exist
if "vocab" not in memory:
    memory["vocab"] = []
if "sentences" not in memory:
    memory["sentences"] = []
if "ai_info" not in memory:
    memory["ai_info"] = {"name": "AI"}

vocabulary = set(memory["vocab"])

# --------------------
# Intents + Templates
# --------------------
intents = {
    "greeting": ["hello", "hi", "hey", "good morning"],
    "ask_feeling": ["how are you", "how's it going", "how are you doing"],
    "goodbye": ["bye", "goodbye", "see you"],
    "ask_name": ["what is your name", "who are you"]
}

templates = {
    "greeting": ["Hello!", "Hi there!", "Hey! How are you?"],
    "ask_feeling": ["I am fine, thank you!", "Doing well, how about you?"],
    "goodbye": ["Goodbye!", "See you later!"],
    "ask_name": ["I am your AI friend.", "You can call me AI."]
}

fallback_responses = [
    "I am still learning.",
    "Can you teach me more?",
    "I do not understand yet.",
    "Tell me another word."
]

# --------------------
# Pop sound function
# --------------------
POP_FILE = "pop.wav"

def play_pop():
    threading.Thread(target=lambda: playsound(POP_FILE, block=True)).start()

# --------------------
# AI Reply Function
# --------------------
def ai_reply(user_input):
    text = user_input.lower().strip()
    ai_name = memory["ai_info"].get("name", "AI")

    # ---------------- Name detection
    match = re.search(r"your name is (\w+)", text)
    if match:
        ai_name_new = match.group(1).capitalize()
        memory["ai_info"]["name"] = ai_name_new
        with open(MEMORY_FILE, "w") as f:
            json.dump(memory, f, indent=2)
        return f"Nice! I am now called {ai_name_new}."

    # ---------------- Math
    math_expr = re.findall(r"[0-9\+\-\*\/\(\)\.]+", text.replace(" ", ""))
    if math_expr:
        try:
            return str(eval(math_expr[0]))
        except:
            return "I can't compute that."

    # ---------------- Intents
    for intent, patterns in intents.items():
        for p in patterns:
            if p in text:
                return random.choice(templates[intent]).replace("AI", ai_name)

    # ---------------- Learn words
    words = re.findall(r"[a-z']+", text)
    for w in words:
        vocabulary.add(w)
    memory["vocab"] = list(vocabulary)
    memory["sentences"].append(words)
    with open(MEMORY_FILE, "w") as f:
        json.dump(memory, f, indent=2)

    # ---------------- Build bigrams
    bigrams = {}
    for sentence in memory["sentences"]:
        for i in range(len(sentence)-1):
            w1, w2 = sentence[i], sentence[i+1]
            if w1 not in bigrams:
                bigrams[w1] = []
            bigrams[w1].append(w2)

    # ---------------- Generate sentence from bigrams
    if len(vocabulary) >= 2:
        seed = random.choice(list(vocabulary))
        sentence = [seed]
        for _ in range(random.randint(2, 5)):
            next_words = bigrams.get(sentence[-1], list(vocabulary))
            next_word = random.choice(next_words)
            sentence.append(next_word)
        sentence_text = " ".join(sentence).capitalize() + random.choice([".", "!", "?"])
        return sentence_text.replace("AI", ai_name)

    # ---------------- Fallback
    return random.choice(fallback_responses).replace("AI", ai_name)

# --------------------
# Typing Simulation (Instant)
# --------------------
def type_ai_sentence(app, sentence):
    """AI types the whole sentence instantly and plays a pop sound."""
    ai_name = memory["ai_info"].get("name", "AI")
    app.chat_area.config(state="normal")
    app.chat_area.insert(tk.END, f"{ai_name}: {sentence}\n")
    app.chat_area.config(state="disabled")
    app.chat_area.yview(tk.END)

    # Play pop sound
    play_pop()

# --------------------
# GUI Application
# --------------------
class ChatApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Neural Chat AI")
        self.root.geometry("650x550")

        # Chat display
        self.chat_area = scrolledtext.ScrolledText(
            root, wrap=tk.WORD, state="disabled", font=("Arial", 11)
        )
        self.chat_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Entry
        self.entry = tk.Entry(root, font=("Arial", 12))
        self.entry.pack(padx=10, pady=5, fill=tk.X)
        self.entry.bind("<Return>", self.send)

        # Send button
        self.send_btn = tk.Button(root, text="Send", command=self.send)
        self.send_btn.pack(pady=5)

        # Initial AI greeting
        type_ai_sentence(self, "Hello! I am learning. Talk to me to teach words.")

    def add_user(self, text):
        self.chat_area.config(state="normal")
        self.chat_area.insert(tk.END, f"\nYou: {text}\n")
        self.chat_area.config(state="disabled")
        self.chat_area.yview(tk.END)

    def send(self, event=None):
        user_text = self.entry.get().strip()
        if not user_text:
            return
        self.entry.delete(0, tk.END)

        self.add_user(user_text)
        response = ai_reply(user_text)
        type_ai_sentence(self, response)

# --------------------
# Start GUI App
# --------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = ChatApp(root)
    root.mainloop()

