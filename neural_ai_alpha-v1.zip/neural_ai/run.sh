gnome-terminal -- bash -c "cd ~/neural_ai && python3 neural_chat_ai.py; exec bash"
