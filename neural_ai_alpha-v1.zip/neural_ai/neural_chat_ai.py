import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import tensorflow as tf
import numpy as np
import json
import re
import random

MEMORY_FILE = "nn_memory.json"
MODEL_FILE = "nn_model.keras"
VOCAB_FILE = "nn_vocab.json"

# ---------------- LOAD MEMORY ----------------
if os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "r") as f:
        sentences = json.load(f)["sentences"]
else:
    sentences = []

# ---------------- VOCAB ----------------
def build_vocab(sentences):
    vocab = sorted(set(word for s in sentences for word in s))
    word_to_id = {w: i for i, w in enumerate(vocab)}
    id_to_word = {i: w for w, i in word_to_id.items()}
    return vocab, word_to_id, id_to_word

def save_vocab(vocab):
    with open(VOCAB_FILE, "w") as f:
        json.dump(vocab, f)

def load_vocab():
    if os.path.exists(VOCAB_FILE):
        with open(VOCAB_FILE, "r") as f:
            vocab = json.load(f)
            word_to_id = {w: i for i, w in enumerate(vocab)}
            id_to_word = {i: w for w, i in word_to_id.items()}
            return vocab, word_to_id, id_to_word
    return [], {}, {}

# ---------------- TRAINING DATA ----------------
def build_data(sentences, word_to_id):
    X, y = [], []
    for s in sentences:
        for i in range(len(s) - 1):
            X.append(word_to_id[s[i]])
            y.append(word_to_id[s[i + 1]])
    return np.array(X), np.array(y)

# ---------------- MODEL ----------------
def create_model(vocab_size):
    model = tf.keras.Sequential([
        tf.keras.layers.Embedding(vocab_size, 16),
        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dense(vocab_size, activation="softmax")
    ])
    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy"
    )
    return model

# ---------------- LOAD MODEL ----------------
vocab, word_to_id, id_to_word = load_vocab()

if os.path.exists(MODEL_FILE) and vocab:
    model = tf.keras.models.load_model(MODEL_FILE)
    print("🧠 Neural brain loaded.")
else:
    model = None

print("\nNeural Chat AI ready.")
print("Talk to me normally.")
print("Type: exit to quit.\n")

# ---------------- CHAT LOOP ----------------
while True:
    user_input = input("You: ").strip().lower()

    if user_input == "exit":
        print("AI shutting down.")
        break

    # Clean input
    words = re.findall(r"[a-z']+", user_input)

    if len(words) < 2:
        print("AI: Tell me a little more.")
        continue

    # Store memory
    sentences.append(words)
    with open(MEMORY_FILE, "w") as f:
        json.dump({"sentences": sentences}, f, indent=2)

    # Rebuild vocab
    vocab, word_to_id, id_to_word = build_vocab(sentences)
    save_vocab(vocab)

    X, y = build_data(sentences, word_to_id)

    # Create or expand model
    if model is None or model.output_shape[-1] != len(vocab):
        model = create_model(len(vocab))

    # Train briefly (NO forgetting)
    model.fit(X, y, epochs=20, verbose=0)
    model.save(MODEL_FILE)

    # ----------- GENERATE RESPONSE -----------
    current = words[-1]
    response = [current]

    for _ in range(random.randint(2, 4)):
        if current not in word_to_id:
            break
        x = np.array([word_to_id[current]])
        probs = model.predict(x, verbose=0)[0]
        next_id = np.random.choice(len(probs), p=probs)
        current = id_to_word[next_id]
        response.append(current)

    print("AI:", " ".join(response))
