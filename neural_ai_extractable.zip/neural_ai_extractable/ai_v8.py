from rapidfuzz import fuzz
import tkinter as tk
import json
import os
import random
import re

MEMORY_FILE = "mimic_memory.json"

# ---------------- MEMORY ----------------

def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    return {"pairs": [], "name": "AI"}

memory = load_memory()

# ---------------- STATE ----------------

last_ai_message = ""

# ---------------- UTILITIES ----------------

def clean(text):
    """Clean input text"""
    if not isinstance(text, str):
        return ""
    return re.sub(r"[^a-zA-Z0-9 ,.!?']", "", text.lower()).strip()

def fuzzy_match(text, patterns, threshold=75):
    """Return True if text fuzzily matches any pattern"""
    if isinstance(patterns, str):
        patterns = [patterns]

    for p in patterns:
        if fuzz.ratio(clean(text), clean(p)) >= threshold:
            return True
    return False

def mimic_reply(user_text):
    global last_ai_message

    user_clean = clean(user_text)
    best_match = None
    highest_score = 0

    for pair in memory["pairs"]:
        # ---- CONTEXT CHECK ----
        if "previous_ai" in pair:
            if not fuzzy_match(last_ai_message, pair["previous_ai"], 75):
                continue

        # ---- INPUT CHECK ----
        inputs = pair["input"]
        if isinstance(inputs, str):
            inputs = [inputs]

        for inp in inputs:
            score = fuzz.ratio(user_clean, clean(inp))
            if score > highest_score:
                highest_score = score
                best_match = pair

    if best_match and highest_score >= 70:
        responses = best_match["response"]
        reply = random.choice(responses) if isinstance(responses, list) else responses
        last_ai_message = reply
        return reply

    last_ai_message = "..."
    return "..."

# ---------------- GUI ----------------

class ChatApp:
    def __init__(self, root):
        self.root = root
        root.title("Mimic Chat AI")

        self.chat_area = tk.Text(root, height=20, width=60)
        self.chat_area.pack(padx=10, pady=10)
        self.chat_area.config(state=tk.DISABLED)

        self.entry = tk.Entry(root, width=50)
        self.entry.pack(side=tk.LEFT, padx=10)
        self.entry.bind("<Return>", self.send)

        self.send_btn = tk.Button(root, text="Send", command=self.send)
        self.send_btn.pack(side=tk.RIGHT, padx=10)

        self.say(f"{memory['name']}: Hi! I learn by talking to you. Say anything.")

    def say(self, text):
        self.chat_area.config(state=tk.NORMAL)
        self.chat_area.insert(tk.END, text + "\n")
        self.chat_area.config(state=tk.DISABLED)
        self.chat_area.see(tk.END)

    def send(self, event=None):
        user_text = self.entry.get().strip()
        if not user_text:
            return

        self.entry.delete(0, tk.END)
        self.say(f"You: {user_text}")

        reply = mimic_reply(user_text)
        self.say(f"{memory['name']}: {reply}")

# ---------------- RUN ----------------

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatApp(root)
    root.mainloop()

